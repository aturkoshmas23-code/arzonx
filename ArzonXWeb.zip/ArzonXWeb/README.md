ARZON X (WebView) - лаунчер
1. Android Studio: File > Open > ин папка, Gradle Sync.
2. Build > Build APK(s), APK-ро ба Realme C61 гузоред ва насб кунед.
3. Танзимот > Барномаҳо > Барномаҳои пешфарз > Экрани асосӣ (Главный экран) > ARZON X.
HTML: app/src/main/assets/index.html
