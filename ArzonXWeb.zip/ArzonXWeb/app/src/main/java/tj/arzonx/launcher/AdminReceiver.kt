package tj.arzonx.launcher

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
