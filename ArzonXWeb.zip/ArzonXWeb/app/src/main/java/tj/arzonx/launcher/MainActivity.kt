package tj.arzonx.launcher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView

    private val pkgs = mapOf(
        "youtube" to listOf("com.google.android.youtube"), "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "instagram" to listOf("com.instagram.android"), "whatsapp" to listOf("com.whatsapp"),
        "facebook" to listOf("com.facebook.katana"), "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web"),
        "play" to listOf("com.android.vending"), "chrome" to listOf("com.android.chrome"),
        "files" to listOf("com.coloros.filemanager", "com.oplus.filemanager", "com.google.android.documentsui", "com.android.documentsui")
    )

    inner class Bridge {
        @JavascriptInterface fun open(k: String) = runOnUiThread { launch(k) }
    }

    private fun launch(k: String) {
        try {
            when (k) {
                "phone" -> startActivity(Intent(Intent.ACTION_DIAL))
                "sms" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
                "camera" -> startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                "contacts" -> startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
                "settings" -> startActivity(Intent(Settings.ACTION_SETTINGS))
                "gallery" -> startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
                "music" -> startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
                else -> {
                    val i = pkgs[k].orEmpty().firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
                    if (i != null) startActivity(i)
                    else if (k == "chrome") startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://")))
                    else Toast.makeText(this, "Барнома насб нашудааст", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Кушода нашуд", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this).apply {
            setBackgroundColor(0xFF03100A.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    // Тугмаи Home: ба экрани асосӣ бозгашт
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); web.evaluateJavascript("go('home')", null) }

    @Deprecated("simple")
    override fun onBackPressed() { web.evaluateJavascript("go('home')", null) }
}
