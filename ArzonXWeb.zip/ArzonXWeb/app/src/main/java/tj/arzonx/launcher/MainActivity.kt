package tj.arzonx.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var torchOn = false

    private val pkgs = mapOf(
        "youtube" to listOf("com.google.android.youtube"), "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "instagram" to listOf("com.instagram.android"), "whatsapp" to listOf("com.whatsapp"),
        "facebook" to listOf("com.facebook.katana"), "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web"),
        "play" to listOf("com.android.vending"), "chrome" to listOf("com.android.chrome"),
        "files" to listOf("com.coloros.filemanager", "com.oplus.filemanager", "com.google.android.documentsui", "com.android.documentsui")
    )

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { js("window.loadApps&&loadApps()") }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface fun open(k: String) = runOnUiThread { launchKey(k) }
        @JavascriptInterface fun launch(p: String) = runOnUiThread { launchPkg(p) }

        @JavascriptInterface fun getApps(): String {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            packageManager.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
                .forEach {
                    val ai = it.activityInfo.applicationInfo
                    arr.put(JSONObject()
                        .put("n", it.loadLabel(packageManager).toString())
                        .put("p", it.activityInfo.packageName)
                        .put("g", ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
                        .put("s", (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0))
                }
            return arr.toString()
        }

        @JavascriptInterface fun menu(p: String) = runOnUiThread {
            AlertDialog.Builder(this@MainActivity).setItems(arrayOf("Маълумот дар бораи барнома", "Нест кардан")) { _, w ->
                if (w == 0) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p")))
                else startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$p")))
            }.show()
        }

        @JavascriptInterface fun getPref(k: String): String = getSharedPreferences("arzon", 0).getString(k, "") ?: ""
        @JavascriptInterface fun setPref(k: String, v: String) { getSharedPreferences("arzon", 0).edit().putString(k, v).apply() }
        @JavascriptInterface fun isAdmin(): Boolean =
            getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this@MainActivity, AdminReceiver::class.java))
        @JavascriptInterface fun torch() = runOnUiThread {
            try {
                val cm = getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                torchOn = !torchOn; cm.setTorchMode(id, torchOn)
            } catch (e: Exception) { }
        }

        // Қулфи воқеии телефон (қулфи системавӣ: ПИН, расм ё изи ангушт)
        @JavascriptInterface fun lockScreen() = runOnUiThread {
            val dpm = getSystemService(DevicePolicyManager::class.java)
            val c = ComponentName(this@MainActivity, AdminReceiver::class.java)
            if (dpm.isAdminActive(c)) dpm.lockNow()
            else startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, c)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Барои қулф кардани экран бо ду пахш"))
        }

        // Кушодани парвандаи огоҳиномаҳо ва танзимоти зуд (равшанӣ, садо, Bluetooth ва ғайра)
        @JavascriptInterface fun expandPanel() = runOnUiThread {
            try {
                val sb = getSystemService("statusbar")
                Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
            } catch (e: Exception) { }
        }
    }

    private fun launchPkg(p: String) {
        val i = packageManager.getLaunchIntentForPackage(p)
        if (i != null) startActivity(i) else Toast.makeText(this, "Кушода нашуд", Toast.LENGTH_SHORT).show()
    }

    private fun launchKey(k: String) {
        try {
            when (k) {
                "phone" -> startActivity(Intent(Intent.ACTION_DIAL))
                "sms" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
                "camera" -> startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                "contacts" -> startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
                "settings" -> startActivity(Intent(Settings.ACTION_SETTINGS))
                "gallery" -> startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
                "music" -> startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
                else -> {
                    val i = pkgs[k].orEmpty().firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
                    if (i != null) startActivity(i)
                    else if (k == "chrome") startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://")))
                    else Toast.makeText(this, "Барнома насб нашудааст", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Кушода нашуд", Toast.LENGTH_SHORT).show()
        }
    }

    private fun bitmapOf(d: Drawable): Bitmap {
        val s = 128
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s); d.draw(Canvas(b)); return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this).apply {
            setBackgroundColor(0xFF03100A.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    val u = r.url
                    if (u.host == "arzonx.local" && u.path?.startsWith("/icon/") == true) {
                        val p = u.lastPathSegment ?: return null
                        return try {
                            val out = ByteArrayOutputStream()
                            bitmapOf(packageManager.getApplicationIcon(p)).compress(Bitmap.CompressFormat.PNG, 100, out)
                            WebResourceResponse("image/png", null, ByteArrayInputStream(out.toByteArray()))
                        } catch (e: Exception) { null }
                    }
                    return null
                }
            }
            val html = assets.open("index.html").bufferedReader().readText()
            loadDataWithBaseURL("https://arzonx.local/", html, "text/html", "utf-8", null)
        }
        setContentView(web)
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED) else registerReceiver(pkgReceiver, f)
    }

    override fun onResume() { super.onResume(); js("window.onShow&&onShow()") }
    override fun onDestroy() { super.onDestroy(); try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { } }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); js("go('home')") }

    @Deprecated("simple")
    override fun onBackPressed() { js("go('home')") }
}
