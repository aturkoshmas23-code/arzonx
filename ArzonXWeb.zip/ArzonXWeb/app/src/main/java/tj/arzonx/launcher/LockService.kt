package tj.arzonx.launcher

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Вақте экран хомӯш мешавад, экрани қулфи ARZON X-ро омода мекунад. */
class LockService : Service() {
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (getSharedPreferences("arzon", 0).getString("pin", "").isNullOrEmpty()) return
            try {
                startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
            } catch (e: Exception) { }
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("lock", "ARZON X қулф", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock").setSmallIcon(R.drawable.ic_launcher).setContentTitle("ARZON X қулф фаъол аст").build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        registerReceiver(rcv, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onDestroy() { try { unregisterReceiver(rcv) } catch (e: Exception) { }; super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}
