package tj.arzonx.launcher

import android.app.Activity
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

/** Экрани қулфи ARZON Market: болои қулфи системавӣ нишон дода мешавад. */
class LockActivity : Activity() {
    private lateinit var web: WebView
    private var torchOn = false
    private var pageReady = false
    private lateinit var speaker: Speaker

    inner class B {
        @JavascriptInterface fun isLock() = true
        @JavascriptInterface fun ready() { pageReady = true }
        @JavascriptInterface fun speak(s: String) { speaker.speak(s) }
        @JavascriptInterface fun isAdmin() = true
        @JavascriptInterface fun getPref(k: String): String = getSharedPreferences("arzon", 0).getString(k, "") ?: ""
        @JavascriptInterface fun setPref(k: String, v: String) { getSharedPreferences("arzon", 0).edit().putString(k, v).apply() }
        @JavascriptInterface fun getApps() = "[]"
        @JavascriptInterface fun open(k: String) {}
        @JavascriptInterface fun launch(p: String) {}
        @JavascriptInterface fun menu(p: String) {}
        @JavascriptInterface fun expandPanel() = false
        @JavascriptInterface fun lockScreen() {}
        @JavascriptInterface fun finishLock() = runOnUiThread { finish() }
        @JavascriptInterface fun torch() = runOnUiThread {
            try {
                val cm = getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                torchOn = !torchOn; cm.setTorchMode(id, torchOn)
            } catch (e: Exception) { }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        speaker = Speaker(this)
        setShowWhenLocked(true)
        web = WebView(this).apply {
            setBackgroundColor(0xFF03100A.toInt())
            settings.javaScriptEnabled = true
            addJavascriptInterface(B(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onRenderProcessGone(v: WebView, d: android.webkit.RenderProcessGoneDetail): Boolean { finish(); return true }
                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    if (r.url.host == "arzonx.local" && r.url.path == "/wall.jpg") {
                        val f = File(filesDir, "wall.jpg")
                        if (f.exists()) return WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Cache-Control" to "no-store"), f.inputStream())
                    }
                    return null
                }
            }
            val html = assets.open("index.html").bufferedReader().readText()
            loadDataWithBaseURL("https://arzonx.local/", html, "text/html", "utf-8", null)
        }
        setContentView(web)
        // Агар экрани қулф 3 сония пайдо нашавад, баста мешавад (то экрани сиёҳ намонад)
        Handler(Looper.getMainLooper()).postDelayed({ if (!pageReady) finish() }, 3000)
    }

    override fun onResume() { super.onResume(); web.onResume(); web.evaluateJavascript("go('lockscr')", null) }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onStop() {
        super.onStop()
        if (getSystemService(PowerManager::class.java).isInteractive) finish()
    }

    override fun onDestroy() { speaker.shutdown(); super.onDestroy() }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); web.evaluateJavascript("go('lockscr')", null) }
    @Deprecated("simple") override fun onBackPressed() {}
}
