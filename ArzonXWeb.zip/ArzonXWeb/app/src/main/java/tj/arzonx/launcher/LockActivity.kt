package tj.arzonx.launcher

import android.app.Activity
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView

/** Экрани қулфи ARZON X: болои қулфи системавӣ нишон дода мешавад. */
class LockActivity : Activity() {
    private lateinit var web: WebView
    private var torchOn = false

    inner class B {
        @JavascriptInterface fun isLock() = true
        @JavascriptInterface fun isAdmin() = true
        @JavascriptInterface fun getPref(k: String): String = getSharedPreferences("arzon", 0).getString(k, "") ?: ""
        @JavascriptInterface fun setPref(k: String, v: String) { getSharedPreferences("arzon", 0).edit().putString(k, v).apply() }
        @JavascriptInterface fun getApps() = "[]"
        @JavascriptInterface fun open(k: String) {}
        @JavascriptInterface fun launch(p: String) {}
        @JavascriptInterface fun menu(p: String) {}
        @JavascriptInterface fun expandPanel() {}
        @JavascriptInterface fun lockScreen() {}
        @JavascriptInterface fun finishLock() = runOnUiThread { finish() }
        @JavascriptInterface fun torch() = runOnUiThread {
            try {
                val cm = getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                torchOn = !torchOn; cm.setTorchMode(id, torchOn)
            } catch (e: Exception) { }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true); setTurnScreenOn(true)
        web = WebView(this).apply {
            setBackgroundColor(0xFF03100A.toInt())
            settings.javaScriptEnabled = true
            addJavascriptInterface(B(), "Android")
            val html = assets.open("index.html").bufferedReader().readText()
            loadDataWithBaseURL("https://arzonx.local/", html, "text/html", "utf-8", null)
        }
        setContentView(web)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); web.evaluateJavascript("go('lockscr')", null) }
    @Deprecated("simple") override fun onBackPressed() {}
}
