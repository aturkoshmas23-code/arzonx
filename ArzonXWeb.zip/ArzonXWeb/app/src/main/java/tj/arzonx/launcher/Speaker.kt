package tj.arzonx.launcher

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Овози барнома (TextToSpeech). Агар тоҷикӣ дастгирӣ нашавад, бо забони русӣ хонда мешавад. */
class Speaker(ctx: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var tg = false
    private var pending: String? = null

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val t = tts!!
                tg = t.isLanguageAvailable(Locale("tg")) >= TextToSpeech.LANG_AVAILABLE
                t.language = if (tg) Locale("tg") else Locale("ru")
                ready = true
                pending?.let { say(it) }; pending = null
            }
        }
    }

    fun speak(s: String) { if (!ready) pending = s else say(s) }

    private fun say(s: String) {
        tts?.speak(if (tg) s else translit(s), TextToSpeech.QUEUE_FLUSH, null, "arzon")
    }

    private fun translit(s: String): String {
        var r = s.replace("ARZON Market", "Арзон Маркет").replace("ARZON X", "Арзон икс").replace("ҷ", "дж").replace("Ҷ", "Дж")
        val from = "ҳҲӯӮӣӢқҚғҒ"; val to = "хХуУиИкКгГ"
        from.forEachIndexed { i, c -> r = r.replace(c, to[i]) }
        return r
    }

    fun shutdown() { tts?.stop(); tts?.shutdown() }
}
