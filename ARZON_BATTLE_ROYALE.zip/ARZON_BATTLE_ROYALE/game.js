(() => {
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const aliveEl=document.getElementById('alive'),hpEl=document.getElementById('hp');
const start=document.getElementById('start'),end=document.getElementById('end');
let W=900,H=600, running=false, keys={}, player, bots=[], bullets=[], loot=[], zone, frame=0, kills=0;
const names=['Душанбе','Хуҷанд','Панҷакент','Кӯлоб','Бохтар'];
function resize(){const r=canvas.getBoundingClientRect();const d=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(r.width*d);canvas.height=Math.round(r.height*d);W=r.width;H=r.height;ctx.setTransform(d,0,0,d,0,0)}
window.addEventListener('resize',resize);resize();
function rand(a,b){return a+Math.random()*(b-a)}
function reset(){
 player={x:W/2,y:H/2,r:11,hp:100,speed:2.6,angle:0,cool:0};
 bots=Array.from({length:11},(_,i)=>({x:rand(35,W-35),y:rand(35,H-35),r:10,hp:55,speed:rand(.65,1.05),cool:rand(20,90),angle:0,name:'Душман '+(i+1)}));
 bullets=[];loot=[];zone={x:W/2,y:H/2,r:Math.min(W,H)*.47};frame=0;kills=0;running=true;aliveEl.textContent='12';hpEl.textContent='100';end.classList.add('hidden');
}
function keyDown(e){if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();keys[e.key.toLowerCase()]=true}
function keyUp(e){keys[e.key.toLowerCase()]=false}
window.addEventListener('keydown',keyDown);window.addEventListener('keyup',keyUp);
document.querySelectorAll('[data-key]').forEach(b=>{const k=b.dataset.key.toLowerCase();b.addEventListener('pointerdown',e=>{e.preventDefault();keys[k]=true});['pointerup','pointercancel','pointerleave'].forEach(ev=>b.addEventListener(ev,()=>keys[k]=false))});
let firing=false;const fireBtn=document.getElementById('fireBtn');fireBtn.addEventListener('pointerdown',()=>firing=true);['pointerup','pointercancel','pointerleave'].forEach(e=>fireBtn.addEventListener(e,()=>firing=false));
canvas.addEventListener('pointermove',e=>{if(player){const r=canvas.getBoundingClientRect();player.angle=Math.atan2(e.clientY-r.top-player.y,e.clientX-r.left-player.x)}});
canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&running)shoot(player,player.angle)});
function shoot(who,a){if(who.cool>0)return;who.cool=who===player?15:55;bullets.push({x:who.x+Math.cos(a)*14,y:who.y+Math.sin(a)*14,vx:Math.cos(a)*6,vy:Math.sin(a)*6,owner:who,r:3,life:65})}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function drawMap(){
 ctx.fillStyle='#78945a';ctx.fillRect(0,0,W,H);
 // fields and terrain
 for(let i=0;i<26;i++){let x=(i*137+41)%W,y=(i*89+23)%H;ctx.fillStyle=i%2?'#6f8950':'#829d60';ctx.beginPath();ctx.arc(x,y,rand(12,30),0,Math.PI*2);ctx.fill()}
 ctx.strokeStyle='#c4b58a';ctx.lineWidth=10;ctx.globalAlpha=.65;ctx.beginPath();ctx.moveTo(0,H*.25);ctx.lineTo(W*.3,H*.34);ctx.lineTo(W*.55,H*.18);ctx.lineTo(W,H*.3);ctx.stroke();ctx.beginPath();ctx.moveTo(W*.12,H);ctx.lineTo(W*.35,H*.65);ctx.lineTo(W*.72,H*.72);ctx.lineTo(W,H*.52);ctx.stroke();ctx.globalAlpha=1;
 names.forEach((n,i)=>{let x=[W*.18,W*.72,W*.28,W*.82,W*.48][i],y=[H*.2,H*.24,H*.78,H*.78,H*.48][i];ctx.fillStyle='#d8e4c3';ctx.fillRect(x-23,y-13,46,25);ctx.fillStyle='#263d2a';ctx.font='10px Arial';ctx.textAlign='center';ctx.fillText(n,x,y+3)});
 // zone
 ctx.strokeStyle='#a9e7ff';ctx.lineWidth=3;ctx.setLineDash([9,7]);ctx.beginPath();ctx.arc(zone.x,zone.y,zone.r,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);
}
function person(p,color){ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle||0);ctx.fillStyle='#0005';ctx.beginPath();ctx.ellipse(2,5,p.r+2,p.r,0,0,Math.PI*2);ctx.fill();ctx.fillStyle=color;ctx.beginPath();ctx.arc(0,0,p.r,0,Math.PI*2);ctx.fill();ctx.fillStyle='#f2d0a3';ctx.beginPath();ctx.arc(3,-3,p.r*.45,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.fillRect(4,-3,p.r+8,5);ctx.restore();if(p!==player){ctx.fillStyle='#222';ctx.fillRect(p.x-12,p.y-p.r-9,24,3);ctx.fillStyle='#e95d4d';ctx.fillRect(p.x-12,p.y-p.r-9,24*Math.max(0,p.hp/55),3)}}
function update(){
 frame++;let dx=0,dy=0;if(keys.w||keys.arrowup)dy--;if(keys.s||keys.arrowdown)dy++;if(keys.a||keys.arrowleft)dx--;if(keys.d||keys.arrowright)dx++;let len=Math.hypot(dx,dy)||1;player.x=clamp(player.x+dx/len*player.speed,12,W-12);player.y=clamp(player.y+dy/len*player.speed,12,H-12);if(dx||dy)player.angle=Math.atan2(dy,dx);
 if((keys[' ']||firing)&&player.cool<=0)shoot(player,player.angle);if(player.cool>0)player.cool--;
 bots.forEach(b=>{if(b.hp<=0)return;let a=Math.atan2(player.y-b.y,player.x-b.x),d=Math.hypot(player.x-b.x,player.y-b.y);b.angle=a;if(d>95){b.x+=Math.cos(a)*b.speed;b.y+=Math.sin(a)*b.speed}else if(d<55){b.x-=Math.cos(a)*b.speed;b.y-=Math.sin(a)*b.speed}if(d<310&&b.cool<=0)shoot(b,a);if(b.cool>0)b.cool--;b.x=clamp(b.x,10,W-10);b.y=clamp(b.y,10,H-10)});
 bullets.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.life--;if(q.owner!==player&&Math.hypot(q.x-player.x,q.y-player.y)<player.r+q.r){player.hp-=12;q.life=0}bots.forEach(b=>{if(q.owner===player&&b.hp>0&&Math.hypot(q.x-b.x,q.y-b.y)<b.r+q.r){b.hp-=28;q.life=0;if(b.hp<=0){kills++;if(Math.random()<.45)loot.push({x:b.x,y:b.y})}}})});bullets=bullets.filter(q=>q.life>0&&q.x>-5&&q.x<W+5&&q.y>-5&&q.y<H+5);
 if(frame%500===0)zone.r=Math.max(65,zone.r-35);
 if(Math.hypot(player.x-zone.x,player.y-zone.y)>zone.r)player.hp-=.12;
 loot.forEach(l=>{if(Math.hypot(player.x-l.x,player.y-l.y)<20){player.hp=Math.min(100,player.hp+20);l.got=true}});loot=loot.filter(l=>!l.got);
 aliveEl.textContent=1+bots.filter(b=>b.hp>0).length;hpEl.textContent=Math.max(0,Math.ceil(player.hp));
 if(player.hp<=0)finish(false);if(bots.every(b=>b.hp<=0))finish(true);
}
function render(){drawMap();loot.forEach(l=>{ctx.fillStyle='#ffd84d';ctx.fillRect(l.x-6,l.y-6,12,12);ctx.fillStyle='#332';ctx.font='9px Arial';ctx.fillText('+HP',l.x-9,l.y-10)});bots.forEach(b=>{if(b.hp>0)person(b,'#b84b3f')});person(player,'#2375d8');bullets.forEach(q=>{ctx.fillStyle='#ffe58a';ctx.beginPath();ctx.arc(q.x,q.y,q.r,0,Math.PI*2);ctx.fill()});ctx.fillStyle='#fff';ctx.font='12px Arial';ctx.textAlign='left';ctx.fillText('Куштаҳо: '+kills,12,20)}
function finish(win){running=false;document.getElementById('result').textContent=win?'ҒАЛАБА!':'БОЗӢ БА ОХИР РАСИД';document.getElementById('resultText').textContent=win?'Ту ғолиби ARZON BATTLE ROYALE шудӣ!':'Куштаҳо: '+kills+' · Боз зинда монданро кӯшиш кун.';end.classList.remove('hidden')}
function loop(){if(running)update();render();requestAnimationFrame(loop)}
document.getElementById('startBtn').onclick=()=>{reset();start.classList.add('hidden')};
document.getElementById('againBtn').onclick=()=>{reset()};
loop();
})();