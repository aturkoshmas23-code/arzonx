package tj.arzonx.launcher

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import org.json.JSONArray
import org.json.JSONObject

/** Огоҳиномаҳоро барои экрани қулф мехонад (танҳо ном ва сарлавҳа). Иҷозати «Доступ к уведомлениям» лозим аст. */
class NotifService : NotificationListenerService() {
    companion object {
        var inst: NotifService? = null
        fun list(pm: PackageManager): JSONArray {
            val a = JSONArray()
            val s = inst ?: return a
            try {
                s.activeNotifications
                    .filter { !it.isOngoing && it.packageName != s.packageName && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
                    .sortedByDescending { it.postTime }.take(6).forEach { n ->
                        val title = n.notification.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
                        val app = try { pm.getApplicationLabel(pm.getApplicationInfo(n.packageName, 0)).toString() } catch (e: Exception) { n.packageName }
                        a.put(JSONObject().put("p", n.packageName).put("a", app).put("t", title).put("w", n.postTime))
                    }
            } catch (e: Exception) { }
            return a
        }
    }
    override fun onListenerConnected() { inst = this }
    override fun onListenerDisconnected() { inst = null }
}
