package tj.arzonx.launcher

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Нишонаи барномаро ҳамчун PNG барои саҳифа медиҳад (https://arzonx.local/icon/<бастаи барнома>). */
fun iconResponse(pm: PackageManager, pkg: String): WebResourceResponse? = try {
    val d = pm.getApplicationIcon(pkg)
    val b = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 128, 128); d.draw(Canvas(b))
    val out = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 100, out)
    WebResourceResponse("image/png", null, ByteArrayInputStream(out.toByteArray()))
} catch (e: Exception) { null }
