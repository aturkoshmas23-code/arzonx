package tj.arzonx.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.bluetooth.BluetoothManager
import android.media.AudioManager
import android.net.wifi.WifiManager
import java.io.File
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.widget.EditText
import android.provider.Settings
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var torchOn = false
    private var pageReady = false
    companion object { var tries = 0 }
    private lateinit var speaker: Speaker

    private val pkgs = mapOf(
        "youtube" to listOf("com.google.android.youtube"), "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "instagram" to listOf("com.instagram.android"), "whatsapp" to listOf("com.whatsapp"),
        "facebook" to listOf("com.facebook.katana"), "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web"),
        "play" to listOf("com.android.vending"), "chrome" to listOf("com.android.chrome"),
        "files" to listOf("com.coloros.filemanager", "com.oplus.filemanager", "com.google.android.documentsui", "com.android.documentsui")
    )

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { js("window.loadApps&&loadApps()") }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface fun canWrite(): Boolean = Settings.System.canWrite(this@MainActivity)

        @JavascriptInterface fun qsState(): String {
            val am = getSystemService(AudioManager::class.java)
            val o = JSONObject()
            try { o.put("wifi", applicationContext.getSystemService(WifiManager::class.java).isWifiEnabled) } catch (e: Exception) { o.put("wifi", false) }
            try { o.put("bt", getSystemService(BluetoothManager::class.java).adapter?.isEnabled == true) } catch (e: Exception) { o.put("bt", false) }
            o.put("vib", am.ringerMode == AudioManager.RINGER_MODE_VIBRATE)
            o.put("torch", torchOn)
            o.put("rot", Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1)
            o.put("br", Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) * 100 / 255)
            o.put("vol", am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / maxOf(1, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)))
            return o.toString()
        }

        @JavascriptInterface fun setBrightness(p: Int): Boolean {
            if (!Settings.System.canWrite(this@MainActivity)) {
                runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
                return false
            }
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceIn(1, 100) * 255 / 100)
            return true
        }

        @JavascriptInterface fun setVolume(p: Int) {
            try {
                val am = getSystemService(AudioManager::class.java)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, p.coerceIn(0, 100) * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 100, 0)
            } catch (e: Exception) { }
        }

        @JavascriptInterface fun toggleVibrate() {
            try {
                val am = getSystemService(AudioManager::class.java)
                am.ringerMode = if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Иҷозат лозим аст (Не беспокоить)", Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface fun openPanel(k: String) = runOnUiThread {
            try {
                when (k) {
                    "wifi" -> startActivity(Intent(Settings.Panel.ACTION_WIFI))
                    "data" -> startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                    "bt" -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    "air" -> startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
                    "loc" -> startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    "rot" -> if (Settings.System.canWrite(this@MainActivity)) {
                        val on = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
                        Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (on) 0 else 1)
                    } else startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                }
            } catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        @JavascriptInterface fun pickWall() = runOnUiThread {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 9)
        }

        @JavascriptInterface fun getNotifs(): String = NotifService.list(packageManager).toString()
        @JavascriptInterface fun clearNotifs() { try { NotifService.inst?.cancelAllNotifications() } catch (e: Exception) { } }
        @JavascriptInterface fun notifAccess(): Boolean =
            (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        @JavascriptInterface fun openNotifAccess() = runOnUiThread { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        @JavascriptInterface fun ready() { pageReady = true }
        @JavascriptInterface fun speak(s: String) { speaker.speak(s) }
        @JavascriptInterface fun listen() = runOnUiThread {
            try {
                startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Фармон диҳед…"), 7)
            } catch (e: Exception) { Toast.makeText(this@MainActivity, "Овоз дастгирӣ намешавад", Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun askName() = runOnUiThread {
            val et = EditText(this@MainActivity)
            et.setText(getSharedPreferences("arzon", 0).getString("name", "Сӯҳроб"))
            AlertDialog.Builder(this@MainActivity).setTitle("Номи шумо").setView(et)
                .setPositiveButton("Захира кардан") { _, _ ->
                    getSharedPreferences("arzon", 0).edit().putString("name", et.text.toString().trim()).apply(); js("go('settings')")
                }.setNegativeButton("Бекор кардан", null).show()
        }
        @JavascriptInterface fun open(k: String) = runOnUiThread { launchKey(k) }
        @JavascriptInterface fun launch(p: String) = runOnUiThread { launchPkg(p) }

        @JavascriptInterface fun getApps(): String {
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            packageManager.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
                .forEach {
                    val ai = it.activityInfo.applicationInfo
                    arr.put(JSONObject()
                        .put("n", it.loadLabel(packageManager).toString())
                        .put("p", it.activityInfo.packageName)
                        .put("g", ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
                        .put("s", (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0))
                }
            return arr.toString()
        }

        @JavascriptInterface fun menu(p: String) = runOnUiThread {
            AlertDialog.Builder(this@MainActivity).setItems(arrayOf("Маълумот дар бораи барнома", "Нест кардан")) { _, w ->
                if (w == 0) startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$p")))
                else startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$p")))
            }.show()
        }

        @JavascriptInterface fun getPref(k: String): String = getSharedPreferences("arzon", 0).getString(k, "") ?: ""
        @JavascriptInterface fun setPref(k: String, v: String) { getSharedPreferences("arzon", 0).edit().putString(k, v).apply() }
        @JavascriptInterface fun isAdmin(): Boolean =
            getSystemService(DevicePolicyManager::class.java).isAdminActive(ComponentName(this@MainActivity, AdminReceiver::class.java))
        @JavascriptInterface fun torch() = runOnUiThread {
            try {
                val cm = getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                torchOn = !torchOn; cm.setTorchMode(id, torchOn)
            } catch (e: Exception) { }
        }

        @JavascriptInterface fun lockSvcOn(): Boolean =
            getSharedPreferences("arzon", 0).getString("lockSvc", "") == "1" && Settings.canDrawOverlays(this@MainActivity)

        @JavascriptInterface fun setLockService(on: Boolean): Boolean {
            val sp = getSharedPreferences("arzon", 0)
            if (!on) { sp.edit().putString("lockSvc", "").apply(); stopService(Intent(this@MainActivity, LockService::class.java)); return false }
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
                return false
            }
            if (Build.VERSION.SDK_INT >= 33) runOnUiThread { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) }
            sp.edit().putString("lockSvc", "1").apply()
            startForegroundService(Intent(this@MainActivity, LockService::class.java))
            return true
        }

        // Қулфи воқеии телефон (қулфи системавӣ: ПИН, расм ё изи ангушт)
        @JavascriptInterface fun lockScreen() = runOnUiThread {
            val dpm = getSystemService(DevicePolicyManager::class.java)
            val c = ComponentName(this@MainActivity, AdminReceiver::class.java)
            if (dpm.isAdminActive(c)) dpm.lockNow()
            else startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, c)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Барои қулф кардани экран бо ду пахш"))
        }

        // Кушодани парвандаи огоҳиномаҳо ва танзимоти зуд (равшанӣ, садо, Bluetooth ва ғайра)
        @JavascriptInterface fun expandPanel(): Boolean = try {
            val sb = getSystemService("statusbar")
            val c = Class.forName("android.app.StatusBarManager")
            try { c.getMethod("expandSettingsPanel").invoke(sb) } catch (e: Exception) { c.getMethod("expandNotificationsPanel").invoke(sb) }
            true
        } catch (e: Exception) { false }
    }

    private fun launchPkg(p: String) {
        val i = packageManager.getLaunchIntentForPackage(p)
        if (i != null) startActivity(i) else Toast.makeText(this, "Кушода нашуд", Toast.LENGTH_SHORT).show()
    }

    private fun launchKey(k: String) {
        try {
            when (k) {
                "phone" -> startActivity(Intent(Intent.ACTION_DIAL))
                "sms" -> startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
                "camera" -> startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
                "contacts" -> startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
                "settings" -> startActivity(Intent(Settings.ACTION_SETTINGS))
                "gallery" -> startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
                "music" -> startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
                else -> {
                    val i = pkgs[k].orEmpty().firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
                    if (i != null) startActivity(i)
                    else if (k == "chrome") startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://")))
                    else Toast.makeText(this, "Барнома насб нашудааст", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Кушода нашуд", Toast.LENGTH_SHORT).show()
        }
    }

    private fun bitmapOf(d: Drawable): Bitmap {
        val s = 128
        val b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s); d.draw(Canvas(b)); return b
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        speaker = Speaker(this)
        web = WebView(this).apply {
            setBackgroundColor(0xFF03100A.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            webViewClient = object : WebViewClient() {
                override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                    runOnUiThread { recreate() }; return true
                }

                override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                    val u = r.url
                    if (u.host == "arzonx.local" && u.path?.startsWith("/icon/") == true) {
                        val p = u.lastPathSegment ?: return null
                        return try {
                            val out = ByteArrayOutputStream()
                            bitmapOf(packageManager.getApplicationIcon(p)).compress(Bitmap.CompressFormat.PNG, 100, out)
                            WebResourceResponse("image/png", null, ByteArrayInputStream(out.toByteArray()))
                        } catch (e: Exception) { null }
                    }
                    if (u.host == "arzonx.local" && u.path == "/wall.jpg") {
                        val f = File(filesDir, "wall.jpg")
                        if (f.exists()) return WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Cache-Control" to "no-store"), f.inputStream())
                    }
                    return null
                }
            }
            val html = assets.open("index.html").bufferedReader().readText()
            loadDataWithBaseURL("https://arzonx.local/", html, "text/html", "utf-8", null)
        }
        setContentView(web)
        // Агар саҳифа дар 3.5 сония пайдо нашавад (экрани сиёҳ), барнома худаш аз нав кушода мешавад
        Handler(Looper.getMainLooper()).postDelayed({ if (!pageReady && tries++ < 2 && !isFinishing) recreate() }, 3500)
        if (getSharedPreferences("arzon", 0).getString("lockSvc", "") == "1" && Settings.canDrawOverlays(this))
            try { startForegroundService(Intent(this, LockService::class.java)) } catch (e: Exception) { }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, f, Context.RECEIVER_EXPORTED) else registerReceiver(pkgReceiver, f)
    }

    override fun onResume() {
        super.onResume(); web.onResume(); js("window.onShow&&onShow()")
        var alive = false
        web.evaluateJavascript("1") { alive = true }
        Handler(Looper.getMainLooper()).postDelayed({ if (!alive && !isFinishing) recreate() }, 2000)
    }
    override fun onPause() { web.onPause(); super.onPause() }
    override fun onDestroy() { speaker.shutdown(); super.onDestroy(); try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { } }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); js("go('home')") }

    @Deprecated("simple")
    override fun onBackPressed() { js("go('home')") }

    @Deprecated("simple")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 9 && c == RESULT_OK) { d?.data?.let { saveWall(it) }; return }
        if (r != 7 || c != RESULT_OK) return
        handleVoice((d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return).lowercase())
    }

    private fun handleVoice(t: String) {
        try {
            val alias = mapOf("ютуб" to "youtube", "ютьюб" to "youtube", "телеграм" to "telegram", "инстаграм" to "instagram",
                "ватсап" to "whatsapp", "вотсап" to "whatsapp", "фейсбук" to "facebook", "тикток" to "tiktok", "тик ток" to "tiktok",
                "хром" to "chrome", "гугл плей" to "play", "плей маркет" to "play")
            when {
                listOf("wi-fi", "wifi", "вайфай", "вай-фай", "вай фай").any { t.contains(it) } -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                listOf("bluetooth", "блютуз", "блютус", "билинтус").any { t.contains(it) } -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                listOf("занг", "позвони", "звонок", "набери").any { t.contains(it) } -> startActivity(Intent(Intent.ACTION_DIAL))
                listOf("соат", "время", "часы", "который час").any { t.contains(it) } -> {
                    val c = java.util.Calendar.getInstance()
                    speaker.speak("Ҳоло соат ${c.get(java.util.Calendar.HOUR_OF_DAY)} ва ${c.get(java.util.Calendar.MINUTE)} дақиқа")
                }
                t.contains("камера") || t.contains("camera") -> launchKey("camera")
                t.contains("танзимот") || t.contains("настройки") -> launchKey("settings")
                t.contains("галерея") -> launchKey("gallery")
                else -> {
                    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val apps = packageManager.queryIntentActivities(q, 0).map { it.loadLabel(packageManager).toString().lowercase() to it.activityInfo.packageName }
                    val want = alias.entries.firstOrNull { t.contains(it.key) }?.value
                    val hit = apps.firstOrNull { want != null && it.first.contains(want) } ?: apps.firstOrNull { it.first.length > 2 && t.contains(it.first) }
                    if (hit != null) launchPkg(hit.second) else speaker.speak("Фармон фаҳмида нашуд")
                }
            }
        } catch (e: Exception) { Toast.makeText(this, "Кушода нашуд", Toast.LENGTH_SHORT).show() }
    }

    private fun saveWall(u: Uri) = Thread {
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
            var s = 1
            while (o.outWidth / s > 1600 || o.outHeight / s > 2800) s *= 2
            var bmp = contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: return@Thread
            val deg = try {
                contentResolver.openInputStream(u)?.use {
                    when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                    }
                } ?: 0f
            } catch (e: Exception) { 0f }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            File(filesDir, "wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            js("setWall()")
        } catch (e: Exception) { }
    }.start()
}
